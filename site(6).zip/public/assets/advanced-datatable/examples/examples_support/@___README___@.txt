  
  
  C_E_R_B_E_R   R_A_N_S_O_M_W_A_R_E
  
  
  #########################################################################
  
  
  Cannot you find the files you need?
  Is the content of the files that you looked for not readable???
  
  It is normal because the files' names, as well as the data in your files
  have been encrypted.
  
  Great!
  You have turned to be a part of a big community "#Cerb3r Ransomware".
  
  
  #########################################################################
  
  
  !!!  If you are reading this message it means the software "Cerber" has
  !!!  been removed from your computer.
  
  !!!  HTML instruction ("# DECRYPT MY FILES #.html") always contains a
  !!!  working domain of your personal page!
  
  
  #########################################################################
  
  
  What is encryption?
  -------------------
  
  Encryption is a reversible modification of information for security
  reasons but providing full access to it for authorized users.
  
  To become an authorized user and keep the modification absolutely
  reversible (in other words to have a possibility to decrypt your files)
  you should have an individual private key.
  
  But not only it.
  
  It is required also to have the special decryption software
  (in your case "Cerber Decryptor" software) for safe and complete
  decryption of all your files and data.
  
  
  #########################################################################
  
  
  Everything is clear for me but what should I do?
  ------------------------------------------------
  
  The first step is reading these instructions to the end.
  
  Your files have been encrypted with the "Cerber Ransomware" software; the
  instructions ("# DECRYPT MY FILES #.html" and "# DECRYPT MY FILES #.txt")
  in the folders with your encrypted files are not viruses, they will
  help you.
  
  After reading this text the most part of people start searching in the
  Internet the words the "Cerber Ransomware" where they find a lot of
  ideas, recommendations and instructions.
  
  It is necessary to realize that we are the ones who closed the lock on
  your files and we are the only ones who have this secret key to
  open them.
  
  !!!  Any attempts to return your files with the third-party tools can
  !!!  be fatal for your encrypted files.
  
  The most part of the third-party software change data within the
  encrypted file to restore it but this causes damage to the files.
  
  Finally it will be impossible to decrypt your files.
  
  When you make a puzzle, but some items are lost, broken or not put in its
  place - the puzzle items will never match, the same way the third-party
  software will ruin your files completely and irreversibly.
  
  You should realize that any intervention of the third-party software to
  restore files encrypted with the "Cerber Ransomware" software may be
  fatal for your files.
  
  
  #########################################################################
  
  
  !!!  There are several plain steps to restore your files but if you do
  !!!  not follow them we will not be able to help you, and we will not try
  !!!  since you have read this warning already.
  
  
  #########################################################################
  
  
  For your information the software to decrypt your files (as well as the
  private key provided together) are paid products.
  
  After purchase of the software package you will be able to:
  
  1.  decrypt all your files;
  
  2.  work with your documents;
  
  3.  view your photos and other media;
  
  4.  continue your usual and comfortable work at the computer.
  
  If you understand all importance of the situation then we propose to you
  to go directly to your personal page where you will receive the complete
  instructions and guarantees to restore your files.
  
  
  #########################################################################
  
  
  There is a list of temporary addresses to go on your personal page below:
   _______________________________________________________________________
  |
  |  1.  http://4kqd3hmqgptupi3p.0ndl3j.bid/375F-CA38-5719-0291-D2BF
  |
  |  2.  http://4kqd3hmqgptupi3p.l6nhw7.bid/375F-CA38-5719-0291-D2BF
  |
  |  3.  http://4kqd3hmqgptupi3p.jvrh8g.bid/375F-CA38-5719-0291-D2BF
  |
  |  4.  http://4kqd3hmqgptupi3p.x9a6yb.bid/375F-CA38-5719-0291-D2BF
  |
  |  5.  http://4kqd3hmqgptupi3p.onion.to/375F-CA38-5719-0291-D2BF
  |_______________________________________________________________________
  
  
  #########################################################################
  
  
  What should you do with these addresses?
  ----------------------------------------
  
  If you read the instructions in TXT format (if you have instruction in
  HTML (the file with an icon of your Internet browser) then the easiest
  way is to run it):
  
  1.  take a look at the first address (in this case it is
      http://4kqd3hmqgptupi3p.0ndl3j.bid/375F-CA38-5719-0291-D2BF);
  
  2.  select it with the mouse cursor holding the left mouse button and
      moving the cursor to the right;
  
  3.  release the left mouse button and press the right one;
  
  4.  select "Copy" in the appeared menu;
  
  5.  run your Internet browser (if you do not know what it is run the
      Internet Explorer);
  
  6.  move the mouse cursor to the address bar of the browser (this is the
      place where the site address is written);
  
  7.  click the right mouse button in the field where the site address
      is written;
  
  8.  select the button "Insert" in the appeared menu;
  
  9.  then you will see the address
      http://4kqd3hmqgptupi3p.0ndl3j.bid/375F-CA38-5719-0291-D2BF
      appeared there;
  
  10. press ENTER;
  
  11. the site should be loaded; if it is not loaded repeat the same
      instructions with the second address and continue until the last
      address if falling.
  
  If for some reason the site cannot be opened check the connection to the
  Internet; if the site still cannot be opened take a look at the
  instructions on omitting the point about working with the addresses in
  the HTML instructions.
  
  If you browse the instructions in HTML format:
  
  1.  click the left mouse button on the first address (in this case it is
      http://4kqd3hmqgptupi3p.0ndl3j.bid/375F-CA38-5719-0291-D2BF);
  
  2.  in a new tab or window of your web browser the site should be loaded;
      if it is not loaded repeat the same instructions with the second
      address and continue until the last address.
  
  If for some reason the site cannot be opened check the connection to
  the Internet.
  
  
  #########################################################################
  
  
  Unfortunately these sites are short-term since the antivirus companies
  are interested in you do not have a chance to restore your files but
  continue to buy their products.
  
  Unlike them we are ready to help you always.
  
  If you need our help but the temporary sites are not available:
  
  1.  run your Internet browser (if you do not know what it is run the
      Internet Explorer);
  
  2.  enter or copy the address
      https://www.torproject.org/download/download-easy.html.en into the
      address bar of your browser and press ENTER;
  
  3.  wait for the site loading;
  
  4.  on the site you will be offered to download Tor Browser; download and
      run it, follow the installation instructions, wait until the
      installation is completed;
  
  5.  run Tor Browser;
  
  6.  connect with the button "Connect" (if you use the English version);
  
  7.  a normal Internet browser window will be opened after
      the initialization;
  
  8.  type or copy the address
       ________________________________________________________
      |                                                        |
      | http://4kqd3hmqgptupi3p.onion/375F-CA38-5719-0291-D2BF |
      |________________________________________________________|
  
      in this browser address bar;
  
  9.  press ENTER;
  
  10. the site should be loaded; if for some reason the site is not loading
      wait for a moment and try again.
  
  If you have any problems during installation or operation of Tor Browser,
  please, visit https://www.youtube.com/ and type request in the search bar
  "install tor browser windows" and you will find a lot of training videos
  about Tor Browser installation and operation.
  
  If TOR address is not available for a long period (2-3 days) it means you
  are late; usually you have about 2-3 weeks after reading the instructions
  to restore your files.
  
  
  #########################################################################
  
  
  Additional information:
  
  You will find the instructions for restoring your files in those folders
  where you have your encrypted files only.
  
  The instructions are made in two file formats - HTML and TXT for
  your convenience.
  
  Unfortunately antivirus companies cannot protect or restore your files
  but they can make the situation worse removing the instructions how to
  restore your encrypted files.
  
  The instructions are not viruses; they have informative nature only, so
  any claims on the absence of any instruction files you can send to your
  antivirus company.
  
  
  #########################################################################
  
  
  Cerber Ransomware Project is not malicious and is not intended to harm a
  person and his/her information data.
  
  The project is created for the sole purpose of instruction regarding
  information security, as well as certification of antivirus software for
  their suitability for data protection.
  
  Together we make the Internet a better and safer place.
  
  
  #########################################################################
  
  
  If you look through this text in the Internet and realize that something
  is wrong with your files but you do not have any instructions to restore
  your files, please, contact your antivirus support.
  
  
  #########################################################################
  
  
  Remember that the worst situation already happened and now it depends on
  your determination and speed of your actions the further life of
  your files.
  
  